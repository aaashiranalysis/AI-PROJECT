import pygame
import sys
import math
import random

pygame.init()

# Screen dimensions
WIDTH, HEIGHT = 800, 600
screen = pygame.display.set_mode((WIDTH, HEIGHT))
pygame.display.set_caption("Hexa-Ludo")

# Fonts
font = pygame.font.SysFont(None, 24)
dice_font = pygame.font.SysFont(None, 48)
info_font = pygame.font.SysFont(None, 36)

# Colors
WHITE = (255, 255, 255)
BLACK = (0, 0, 0)
YELLOW = (255, 255, 0)
GREEN = (0, 255, 0)
RED = (255, 0, 0)
BLUE = (0, 0, 255)

# Hexagon properties
HEX_RADIUS = 40
HEX_WIDTH = math.sqrt(3) * HEX_RADIUS
HEX_HEIGHT = 2 * HEX_RADIUS

# Initialize positions for hexagonal tiles (24 tiles)
positions = {}
counter = 1
offset_x = WIDTH // 2
offset_y = 80
rows = 5
cols = 5

# Create the hexagonal grid for 24 tiles
for row in range(rows):
    for col in range(cols):
        if counter <= 24:
            x = offset_x + (col - row / 2) * HEX_WIDTH
            y = offset_y + row * 0.75 * HEX_HEIGHT
            positions[counter] = (x, y)
            counter += 1

# Set of power-up tiles
power_up_tiles = {3, 6, 9, 12, 15, 18}

# Player settings
player_colors = [GREEN, BLUE, RED]
player_positions = [1, 1, 1]  # Start positions
player_names = ["Player 1", "Player 2", "AI"]
current_player = 0
winner = None

# Game variables
clock = pygame.time.Clock()
game_mode = "pvai"  # Player vs AI mode

# Function to render hexagonal shape
def hex_corners(center_x, center_y):
    angles = [math.radians(60 * i) for i in range(6)]
    return [(center_x + HEX_RADIUS * math.cos(a), center_y + HEX_RADIUS * math.sin(a)) for a in angles]

# Function to draw hexagonal shapes
def draw_hex(center_x, center_y, color, width=1):
    pygame.draw.polygon(screen, color, hex_corners(center_x, center_y), width)

# Function to draw filled hexagonal shapes
def draw_filled_hex(center_x, center_y, fill_color):
    pygame.draw.polygon(screen, fill_color, hex_corners(center_x, center_y))

# Function to display text on the screen
def draw_text(text, pos, font=font, color=BLACK):
    label = font.render(text, True, color)
    screen.blit(label, pos)

# Function to roll the dice with animation
def roll_dice_animation():
    for _ in range(5):
        temp = random.randint(1, 6)
        render_dice(temp)
        pygame.display.flip()
        pygame.time.delay(150)
    return temp

# Function to render the dice value
def render_dice(value):
    pygame.draw.rect(screen, WHITE, (WIDTH // 2 - 60, 10, 120, 50))
    text = dice_font.render(f'Dice: {value}', True, BLACK)
    screen.blit(text, (WIDTH // 2 - text.get_width() // 2, 15))

# Function to check if a player is blocking another
def check_blocking():
    for i in range(3):
        if i != current_player and player_positions[current_player] == player_positions[i]:
            player_positions[i] -= 1
            if player_positions[i] < 1:
                player_positions[i] = 1
            break

# Function to show win animation
def show_win_animation():
    for _ in range(50):
        x = random.randint(0, WIDTH)
        y = random.randint(0, HEIGHT)
        color = random.choice([RED, GREEN, BLUE])
        pygame.draw.circle(screen, color, (x, y), 5)
        pygame.display.flip()
        pygame.time.delay(50)

# Function to draw player status
def draw_player_status():
    draw_text(f"Player: {player_names[current_player]}", (20, 60), info_font)
    draw_text(f"Moves: {player_positions[current_player] - 1}", (20, 100), info_font)
    if player_positions[current_player] in power_up_tiles:
        draw_text("Power-Up: Active", (20, 140), info_font)
    else:
        draw_text("Power-Up: None", (20, 140), info_font)

# Function to show the end game screen
def show_end_game_screen():
    draw_text(f"{winner} Wins!", (WIDTH // 2 - 100, HEIGHT // 2 - 100), info_font)
    draw_text("Game Over", (WIDTH // 2 - 80, HEIGHT // 2 - 60), info_font)
    draw_text("Final Score:", (WIDTH // 2 - 100, HEIGHT // 2 - 20), info_font)
    for i, name in enumerate(player_names):
        draw_text(f"{name}: {player_positions[i] - 1} moves", (WIDTH // 2 - 100, HEIGHT // 2 + 30 + 30 * i), info_font)

# Function to apply the power-up effect when landing on a power-up tile
def apply_power_up_effect():
    if player_positions[current_player] in power_up_tiles:
        power_up_tile = player_positions[current_player]
        print(f"{player_names[current_player]} landed on a power-up tile {power_up_tile}!")
        
        # Example power-up effect: roll an extra time
        if random.choice([True, False]):
            print(f"{player_names[current_player]} gets an extra roll!")
            return True  # Player gets an extra roll
        else:
            print(f"{player_names[current_player]} gets to move an extra space!")
            player_positions[current_player] += 1  # Move an extra space
    return False  # No extra effect

# Minimax AI with Alpha-Beta Pruning
def minimax(depth, alpha, beta, maximizing_player):
    if depth == 0 or winner:  # Base case: Either we reached max depth or someone won
        return evaluate_board()

    valid_moves = get_valid_moves(current_player)
    best_move = None

    if maximizing_player:
        max_eval = -float('inf')
        for move in valid_moves:
            simulate_move(move)
            eval = minimax(depth - 1, alpha, beta, False)
            undo_move(move)
            max_eval = max(max_eval, eval)
            alpha = max(alpha, eval)
            if beta <= alpha:
                break
        return max_eval
    else:
        min_eval = float('inf')
        for move in valid_moves:
            simulate_move(move)
            eval = minimax(depth - 1, alpha, beta, True)
            undo_move(move)
            min_eval = min(min_eval, eval)
            beta = min(beta, eval)
            if beta <= alpha:
                break
        return min_eval

def evaluate_board():
    # Here, we can evaluate the current board state. For now, returning random value.
    return random.randint(-10, 10)

def get_valid_moves(player):
    # Returns a list of valid moves for the player. For simplicity, returning all tiles.
    return [i for i in range(1, 25)]

def simulate_move(move):
    player_positions[current_player] = move

def undo_move(move):
    player_positions[current_player] = move

# Main game loop
running = True
while running:
    screen.fill(WHITE)

    # Draw hexagonal tiles
    for num, (x, y) in positions.items():
        color = YELLOW if num in power_up_tiles else (180, 180, 180)
        draw_hex(x, y, color)
        draw_text(str(num), (x - 8, y - 10))

    # Draw player positions
    for i, pos in enumerate(player_positions):
        if pos in positions:
            px, py = positions[pos]
            draw_filled_hex(px, py, player_colors[i])

    # Draw player status
    draw_player_status()

    # Display winner if any
    if winner:
        show_win_animation()
        show_end_game_screen()

    pygame.display.flip()

    # AI Move
    if game_mode == "pvai" and current_player == 2 and not winner:
        pygame.time.delay(500)
        roll = random.randint(1, 6)
        render_dice(roll)
        pygame.display.flip()
        pygame.time.delay(500)

        player_positions[current_player] += roll
        if player_positions[current_player] > 24:
            player_positions[current_player] = 24

        print(f"{player_names[current_player]} rolled a {roll}, moved to tile {player_positions[current_player]}")

        check_blocking()

        # Apply power-up effects
        if apply_power_up_effect():
            continue  # Skip to next round to handle extra roll

        if player_positions[current_player] >= 24:
            player_positions[current_player] = 24
            winner = player_names[current_player]
        elif player_positions[current_player] not in power_up_tiles:
            current_player = (current_player + 1) % 3

    # Player's Move
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            running = False

        if event.type == pygame.KEYDOWN and not winner:
            if event.key == pygame.K_SPACE:
                if game_mode == "pvp" or current_player != 2:
                    roll = roll_dice_animation()
                    player_positions[current_player] += roll
                    if player_positions[current_player] > 24:
                        player_positions[current_player] = 24

                    print(f"{player_names[current_player]} rolled a {roll}, moved to tile {player_positions[current_player]}")

                    check_blocking()

                    # Apply power-up effects
                    if apply_power_up_effect():
                        continue  # Skip to next round to handle extra roll

                    if player_positions[current_player] >= 24:
                        player_positions[current_player] = 24
                        winner = player_names[current_player]
                    elif player_positions[current_player] not in power_up_tiles:
                        current_player = (current_player + 1) % 3

    clock.tick(30)

pygame.quit()
sys.exit()
